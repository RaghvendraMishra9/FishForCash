﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FishForCash.Repository.DB
{
    public class RegisteredPlayerModel
    {
        public int Day { get; set; }
        public int Players { get; set; }
    }
}
