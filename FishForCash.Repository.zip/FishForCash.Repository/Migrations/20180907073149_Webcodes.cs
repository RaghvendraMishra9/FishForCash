﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace FishForCash.Repository.Migrations
{
    public partial class Webcodes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "RecordSources",
                columns: table => new
                {
                    RecordSourceId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    RecordSourceName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RecordSources", x => x.RecordSourceId);
                });

            migrationBuilder.CreateTable(
                name: "WebCodes",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AssignDateIssued = table.Column<DateTime>(nullable: false),
                    GameCodePlayed = table.Column<bool>(nullable: false),
                    PLayerId = table.Column<int>(nullable: true),
                    RecordSourceId = table.Column<int>(nullable: true),
                    UsedSatus = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WebCodes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WebCodes_Players_PLayerId",
                        column: x => x.PLayerId,
                        principalTable: "Players",
                        principalColumn: "PLayerId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_WebCodes_RecordSources_RecordSourceId",
                        column: x => x.RecordSourceId,
                        principalTable: "RecordSources",
                        principalColumn: "RecordSourceId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_WebCodes_PLayerId",
                table: "WebCodes",
                column: "PLayerId");

            migrationBuilder.CreateIndex(
                name: "IX_WebCodes_RecordSourceId",
                table: "WebCodes",
                column: "RecordSourceId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "WebCodes");

            migrationBuilder.DropTable(
                name: "RecordSources");
        }
    }
}
