﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace FishForCash.Repository.Migrations
{
    public partial class UpdateProcGetRegisteredPlayer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var sp = @"CREATE PROC Proc_GetRegisteredPlayers
 AS
 BEGIN
  DECLARE @LastRecords TABLE 
(
[Day]      INT        ,
Players    INT    
)

 DECLARE @dayNum int
 set @dayNum=1
 WHILE @dayNum>=1 and @dayNum<=30
 begin

 INSERT INTO @LastRecords VALUES(DAY(GETDATE()-@dayNum),0)
 
  UPDATE @LastRecords
 SET Players=( SELECT COUNT(*) FROM PLAYERS  P
 WHERE  DAY(P.CreatedDate) = DAY(GETDATE()-@dayNum)) WHERE [DAY]=DAY(GETDATE()-@dayNum)

  SET @dayNum=@dayNum+1;
 end
  SELECT *FROM @LastRecords 
 END";

            migrationBuilder.Sql(sp);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
